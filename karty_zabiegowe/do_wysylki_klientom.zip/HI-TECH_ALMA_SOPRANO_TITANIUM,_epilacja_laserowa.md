﻿# HI-TECH: ALMA SOPRANO TITANIUM, epilacja laserowa

Zweryfikuj zawartość karty zabiegowej dla zabiegu HI-TECH: ALMA SOPRANO TITANIUM, epilacja laserowa
Czy aktualnie się Pan/i na coś leczy?
Tak    Nie
Jeśli tak, to na co?
Czy przyjmuje Pan/i jakieś leki na stałe?
Tak    Nie
Jeśli tak, prosimy o podanie dokładnej nazwy leku, w jakiej dawce i częstotliwości jest przyjmowany:
Czy cierpi lub cierpiał/a Pan/i na którekolwiek z poniżej wymienionych chorób?
CHOROBY NOWOTWOROWECHOROBY SERCACHOROBY UKŁADU KRĄŻENIACHOROBY NACZYŃ KRWIONOŚNYCHCHOROBY PŁUCCHOROBY UKŁADU POKARMOWEGOCHOROBY WĄTROBYCHOROBY UKŁADU MOCZOWEGOZABURZENIA METABOLICZNECHOROBY TARCZYCYZABURZENIA HORMONALNECHOROBY UKŁADU NERWOWEGOCHOROBY KRWI I UKŁADU KRZEPNIĘCIACHOROBY OCZUBRAK
Kontynuacja pytania powyżej:
CHOROBY UKŁADU KOSTNEGOCHOROBY ZAKAŹNECHOROBY SKÓRNECHOROBY PSYCHOSOMATYCZNEBRAK
Jeśli występuje lub występowała u Pana/i inna choroba lub któraś z powyżej wymienionych proszę zaznaczyć ,,Tak'' i opisać konkretne schorzenie.
Jeśli nie występuje prosimy zaznaczyć ,,Nie''.
Tak    Nie
Jeśli tak, prosimy o opisanie choroby.
Jeśli została wyleczona - jaki odstęp czasu upłynął?
Czy jest Pan/i na coś uczulony/a? Lidokaina, lateks, maści, inne...
Tak    Nie
Jeśli tak, to co?
Czy posiada Pan/i rozrusznik serca lub inne metalowe implanty?
Tak    Nie
Jeśli tak, to co dokładnie ?
Czy występują u Pana/Pani: obrzęki, pokrzywka, znamiona barwnikowe, swędzenie?
Tak    Nie
Jeśli tak, to co dokładnie?
Czy występuje obecnie u Pana/Pani opryszczka?
Tak    Nie
Czy występują u Pana/Pani inne dolegliwości niż te powyżej wymienione?
Tak    Nie
Jeśli tak, to jakie ?
Czy pali Pan/i papierosy?
Tak    Nie
Jeśli tak, to ile dziennie i od kiedy?
Czy pił/a Pan/i alkohol w ciągu ostatnich 24 godzin?
Tak    Nie
Jeśli tak, to co i w jakiej ilości ?
Czy zażywa Pan/i środki uspakajające, nasenne, narkotyki?
Tak    Nie
Jeśli tak, to jakie ?
Czy w ciągu ostatnich dwóch tygodni przyjmował/a Pan/i antybiotyk lub leki światłouczulające ?
Tak    Nie
Jeśli tak, to jakie, kiedy i w jakiej dawce ?
Czy przyjmuje Pan/i lub przyjmował/a Pan/i w ciagu ostatnich 6 miesięcy Izotek lub inne leki/maści na trądzik?
Tak    Nie
Jeśli tak, to jakie i kiedy?
Czy lekarz prowadzący wyraził zgodę na wykonanie powyższego zabiegu?
Czy stosuje Pan/i ochronę przeciwsłoneczną?
Tak, codziennie rano i reaplikuje w ciągu dnia
Tak, ale tylko raz dziennie
Tak, ale tylko latem
Sporadycznie
Nie
Czy stosuje Pan/i jakąś suplementacje?
Tak    Nie
Jeśli tak, to co Pan/i suplementuje?
Czy w najbliższych 2 tygodniach był/a lub planuje Pan/i wyjechać na urlop do słonecznego/ mroźnego miejsca?
Tak    Nie
Jeśli tak, to gdzie?
Czy korzysta Pan/i z solarium?
Tak    Nie
Jeśli tak, to jak często i kiedy ostatnio?
Czy przyjmuje Pan/i aspirynę lub leki przeciwzakrzepowe?
Tak    Nie
Jeśli tak, to jakie ?
Czy pił/a Pan/i w ciągu ostatnich dwóch tygodni zioła o działaniu fotouczulającym? (rumianek, pokrzywa, nagietek, arnika, skrzyp, stokrotka)
Tak    Nie
Jeśli tak, to jakie i kiedy ?
Czy w ciągu ostatnich kilku dni przyjmował/a Pan/i jakieś lekki przeciwbólowe (ibuprofen, ketonal, aspiryna, ibuprom, nurofen, pyralgina)?
Tak    Nie
Jeśli tak, to jakie i kiedy ostatnio?
Czy w obrębie skóry przeznaczonej do zabiegu pojawił się kiedykolwiek stan zapalny,
infekcja wirusowa, bakteryjna?
Tak    Nie
Jeśli tak, to co dokładnie ?
Czy używał/a Pan/i w ciągu ostatnich 4 tygodni kremów z retinolem?
Tak    Nie
Jeśli tak, to w jakim stężeniu i kiedy ostatnio?
Czy w ostatnich 7 dniach były wykonywane jakiekolwiek inne zabiegi
na skórze w miejscu które ma być poddane zabiegowi?
Tak    Nie
Jeśli tak, to jakie ?
Czy stosuje Pan/i suplementację?
Proszę wybrać z poniższych propozycji:
Witamina AWitaminy z grupy BWitamina CWitamina DWitamina EMultiwitaminy
Żelazo
Magnez
Cynk
Kolagen
Omega 3Probiotyki
Biotyna
Nie stosuję suplementów
Czy przyjmuje Pan/i inne niż wyżej wymienione suplementy?
Tak    Nie
Jeśli tak, proszę wymienić:
Czy jest Pani w ciąży?
Tak
Nie
Nie dotyczy
Czy karmi Pani piersią?
Tak
Nie
Nie dotyczy
Czy stosuje Pani doustne środki antykoncepcyjne?
Tak
Nie
Nie dotyczy
Czy ma Pan/i na coś alergię?
Tak    Nie
Jeśli tak, to na co:
Czy opalał/a Pan/i skórę w obszarze zabiegowym w przeciągu ostatnich dwóch tygodni?
Tak    Nie
Czy stosował/a Pan/i samoopalacz (lub balsam brązujący z drobinkami) w obszarze zabiegowym w ciągu ostatnich dwóch tygodni?
Tak    Nie
Czy ma Pan/i wykonany tatuaż w obszarze zabiegowym?
Tak    Nie
Jeśli tak, proszę napisać na jakiej części ciała się znajduje:
Czy stosuje Pan/i SPF?
Tak, przez cały rok reaplikuję
Tak, raz dziennie
Tylko latem
SporadycznieNIe
Ile wody dziennie Pan/i pije?
<1l1-1,5l1,5-2l>2

## Klauzula informacyjna RODO

KLAUZULA INFORMACYJNA DOTYCZĄCA PRZETWARZANIA DANYCH OSOBOWYCHAdministratorem Twoich danych osobowych jest BRAVE EDUCATION SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ z siedzibą w POZNAŃ, przy ul. GŁOGOWSKA 216 (dalej jako „Administrator” lub „my”) Nasze dane kontaktowe:
Jeśli masz jakiekolwiek pytania odnośnie przetwarzania przez nas Twoich danych lub chcesz zrealizować swoje uprawnienia, skontaktuj się z nami na adres firmy lub adres e-mail: redsxiii@gmail.comW jakich celach i na jakich podstawach prawnych będziemy przetwarzać Twoje dane?
CEL: Wykonanie umowy (usługi) lub podjęcie działań przed jej zawarciem i działania związane z wykonaniem umowy – tj. np. wykonanie określonego zabiegu kosmetycznego, realizacja zamówienia produktu, doradztwo w zakresie zasad pielęgnacji, w tym ułożenie Beauty
Planów W tym celu możemy przesyłać na podany przez Ciebie adres e-mail lub numer telefonu informacje związane z umową np. zalecenia pozabiegowe, informacje związane z rejestracją konta w aplikacji, szczegóły dotyczące np. Beauty
Planów
PODSTAWA PRAWNA- w zakresie w jakim przetwarzanie danych jest niezbędne dla realizacji umowy – podstawą prawną będzie wykonanie umowy (podjęcie czynności niezbędnych przed nawiązaniem umowy) (art. 6 ust. 1 lit. b RODO); - w zakresie w jakim z wykonaniem umowy wiązać się będzie realizacja określonych obowiązków wynikających z przepisów prawa (np. podatkowych, księgowych etc.) podstawą prawną będzie stosowny przepis prawa (art. 6 ust. 1 lit. c RODO);- w zakresie w jakim przetwarzanie będzie wykraczać poza to co niezbędne dla zawarcia i wykonania umowy – będziemy przetwarzać dane związane z umową w oparciu o prawnie uzasadniony interes – np. w związku z wysyłaniem zaleceń pozabiegowych, rejestracją w systemie, wysyłaniem informacji dotyczących Beauty
Planu, etc. (art. 6 ust. 1 lit. f RODO); - dane możemy również przetwarzać w zakresie niezbędnym dla ustalenia, dochodzenia lub obroną przed roszczeniami, w tym zgłoszeniem szkód do ubezpieczyciela w oparciu o nasz prawnie uzasadniony interes (art. 6 ust. 1 lit. f RODO).
SPRZECIW: W przypadku przetwarzania przez nas danych w oparciu o prawnie uzasadniony interes masz prawo zgłoszenia sprzeciwu z przyczyn związanych ze swoją szczególną sytuacją. Sprzeciw możesz zgłosić pisząc do nas na adres e-mail redsxiii@gmail.com- dane o stanie zdrowia (np. dane o przyjmowanych lekach, przebytych chorobach, alergiach, ciąży etc. podane przez Ciebie) - w zakresie w jakim jest to niezbędne dla bezpiecznego wykonania zabiegów - u nas są przetwarzane na podstawie wyraźnej zgody na ich przetwarzanie (art. 9 ust. 2 lit. a RODO). Zgoda jest dobrowolna, lecz niezbędna do korzystania z zabiegów kosmetycznych (wykonania umowy).
Do czasu rozpoczęcia zabiegu możesz wycofać zgodę ustnie w Salonie, wówczas pracownik Salonu poczyni odpowiednią notatkę w aplikacji. Wycofanie zgody nie wpływa na zgodność z prawem przetwarzania, którego dokonano na podstawie zgody przed jej wycofaniem.Po rozpoczęciu wykonywania zabiegu dane o stanie zdrowia będą przechowywane dla celów ustalenia, dochodzenia lub obrony przed roszczeniami na podstawie art. 9 ust. 2 lit. f. RODO.
CEL: Odpowiedzi na zapytania
PODSTAWA PRAWNAPodstawą prawną jest nasz prawnie uzasadniony interes polegający na konieczności ustosunkowania się do Twojego zapytania (art. 6 ust. 1 lit. f RODO).
SPRZECIW: W przypadku przetwarzania przez nas danych w oparciu o prawnie uzasadniony interes masz prawo zgłoszenia sprzeciwu z przyczyn związanych ze swoją szczególną sytuacją. Sprzeciw możesz zgłosić pisząc do nas na adres e-mail redsxiii@gmail.comW przypadku, gdy odpowiedzi na zapytania dotyczą umówienia usługi lub zakupu produktu podstawą prawną może być czynność bezpośrednio poprzedzająca zawarcie umowy (art. 6 ust. 1 lit. b RODO).
CEL: Wnioski dotyczące realizacji praw wynikających z RODO lub innych właściwych przepisów
PODSTAWA PRAWNAPodstawą prawną jest nasz obowiązek prawny (art. 6 ust. 1 lit. c RODO) związany z koniecznością realizacji praw osób, których dane dotyczą oraz wykazania prawidłowości wykonania naszych obowiązków.
CEL: Reklamacje
PODSTAWA PRAWNAPodstawą prawną jest nasz lub Twój prawnie uzasadniony interes polegający na komunikacji w związku z daną reklamacją, a następnie w celu obrony przed roszczeniami (art. 6 ust. 1 lit. f RODO).
SPRZECIW: W przypadku przetwarzania przez nas danych w oparciu o prawnie uzasadniony interes masz prawo zgłoszenia sprzeciwu z przyczyn związanych ze swoją szczególną sytuacją. Sprzeciw możesz zgłosić pisząc do nas na adres e-mail redsxiii@gmail.com
Czy podanie Twoich danych jest obowiązkowe?Podanie danych jest dobrowolne. Jednakże niepodanie danych, które są niezbędne dla realizacji określonych powyżej celów może odpowiednio uniemożliwić realizację tych celów, np. niepodanie wymaganych danych będzie skutkować niemożnością wykonania zabiegu, zamówienia produktu itp.
Jak długo przechowujemy Twoje dane?Twoje dane przechowujemy przez następujące okresy w zależności od podstaw prawnych (celów przetwarzania):Wykonanie umowy oraz czynności poprzedzające lub związane z wykonaniem umowy: Twoje dane będą przechowane tak długo jak to jest niezbędne dla realizacji celów dla których zostały zebrane, w tym wykonania umowy (np. przeprowadzenia zabiegu, dostarczenia produktu, odpowiedzi na zapytanie które można zakwalifikować jako czynność poprzedzającą zawarcie umowy) który to okres zostanie wydłużony o stosowny okres przedawnienia roszczeń.Nasze obowiązki prawne: W przypadkach, gdy przetwarzanie Twoich danych służy realizacji obowiązków wynikających z przepisów prawa, będziemy przechowywać Twoje dane przez okresy wskazane w takich przepisach obowiązującego prawa.Twoja zgoda: Twoje dane będą przetwarzane do czasu wycofania udzielonej przez Ciebie zgody na ich przetwarzanie. W przypadkach w których te same dane są przetwarzane również w innych celach, w oparciu o inne podstawy prawne, będziemy mogli je przetwarzać w oparciu o inną niż zgoda właściwą podstawę prawną nawet po wycofaniu przez Ciebie zgody.Prawnie uzasadniony interes: Twoje dane będą przetwarzane do czasu zgłoszenia przez Ciebie skutecznego sprzeciwu względem ich przetwarzania lub do czasu gdy wykażemy istnienie podstaw do ustalenia, dochodzenia lub obrony roszczeń. Oznacza to, że po zgłoszeniu przez Ciebie sprzeciwu dokonamy wyważenia Twoich i naszych interesów. Wówczas nie będziemy już przetwarzać Twoich danych osobowych, chyba że wykażemy istnienie ważnych prawnie uzasadnionych podstaw do przetwarzania, nadrzędnych wobec Twoich interesów, praw i wolności, lub istnienie podstaw do ustalenia, dochodzenia lub obrony roszczeń.
Gdzie są przetwarzane Twoje dane osobowe?Twoje dane osobowe są przetwarzane, w tym przechowywane na terenie Europejskiego Obszaru Gospodarczego.
Komu są przekazywane Twoje dane osobowe?Odbiorcami Twoich danych osobowych są podmioty z nami współpracujące lub dostarczające usługi na naszą rzecz, np. podmioty zajmujące się obsługą systemów IT, archiwizacją dokumentacji, obsługą prawną, rachunkowo - księgową czy też jakiekolwiek inne podmioty, z którymi zawarliśmy umowę powierzenia przetwarzania danych i które są zobowiązane do przetwarzania Twoich danych zgodnie z naszymi wskazówkami. Odbiorcami Twoich danych mogą być także organy nadzorujące przestrzeganie prawa, organ regulacyjne i inne organy administracji publicznej, sądy i organy ścigania (wyłącznie w zakresie wynikającym z obowiązujących przepisów prawa).
Jakie są Twoje prawa?Możesz zwrócić się do nas z określonym żądaniem za pośrednictwem adres e-mail redsxiii@gmail.com lub na nasz adres korespondencyjny. Prosimy wówczas o wskazanie z jakiego prawa i w jakim zakresie chcesz skorzystać. Po wpłynięciu Twojego żądania i ewentualnej weryfikacji Twojej tożsamości podejmiemy w związku z Twoim żądaniem odpowiednie działania.Zgodnie z prawem otrzymasz od nas stosowną odpowiedź tak szybko, jak to możliwe, ale (co do zasady) nie później niż w ciągu miesiąca. W sytuacji, w której Twoje żądanie jest skomplikowane lub prosisz nas jednocześnie o realizację wielu żądań, termin ten może został przedłużony maksymalnie o kolejne dwa miesiące. W takim przypadku zostaniesz poinformowany/poinformowana o takim przedłużeniu terminu.Przysługują Tobie następujące prawa:- prawo dostępu do treści swoich danych, otrzymania ich kopii, żądania ich sprostowania, usunięcia lub ograniczenia ich przetwarzania;- wniesienia sprzeciwu wobec przetwarzania danych osobowych z przyczyn związanych z Twoją szczególną sytuacją w zakresie, w jakim podstawą przetwarzania danych osobowych jest prawnie uzasadniony interes;- przenoszenia danych osobowych w zakresie, w jakim Twoje dane są przetwarzane w celu zawarcia i wykonywania umowy lub na podstawie zgody;- wycofania wyrażonej zgody w dowolnym momencie bez wpływu na legalność przetwarzania dokonanego przed takim wycofaniem. W przypadkach w których te same dane są przetwarzane również w innych celach, w oparciu o inne podstawy prawne, będziemy mogli je przetwarzać w oparciu o inną niż zgoda właściwą podstawę prawną. Wówczas poinformujemy Cię o tym;- Ochrona Twoich danych osobowych jest dla nas priorytetem.
Jeśli jednak uznasz, że przetwarzając Twoje dane osobowe naruszamy RODO, masz prawo wniesienia skargi do Prezesa Urzędu Ochrony Danych Osobowych adres: Stawki 2, 00-193 Warszawa.
ZGODA NA ZABIEG I ZWIĄZANE Z NIM PRZETWARZANIE DANYCH O STANIE ZDROWIANiniejszym oświadczam, że wyrażam świadomą zgodę na wykonanie powyższego zabiegu. Oświadczam, że poinformowano mnie o:1. możliwych powikłaniach,2. powikłaniach nietypowych,3. ryzyku zabiegu i jego następstwach,4. przeciwskazaniach do wykonania zabiegu,5. szczegółowej technice wykonania zabiegu,6. sposobie wykonania zabiegu.Ponadto oświadczam, że miałem/miałam możliwość zadawania wszelkich pytań i uzyskania wyjaśnień jakich oczekiwałem/oczekiwałam. Rozumiem, że pozytywne efekty zabiegu nie są zagwarantowane. Wszystkie informacje przekazane przez kosmetologa są dla mnie w pełni jasne i zrozumiałe. Jednocześnie oświadczam, że udzieliłem/udzieliłam aktualnych i kompletnych informacji co do mojego stanu zdrowia.Mam świadomość, że dla bezpiecznego wykonania zabiegów muszę podać dane o stanie zdrowia (np. dane o alergiach, stosowanych lekach, chorobach, ciąży) wskazane w karcie zabiegowej. Niniejszym składając poniżej podpis wyrażam wyraźną zgodę na ich przetwarzanie w celu wykonania zabiegów.Wycofanie zgody jest możliwe do czasu rozpoczęcia zabiegu ustnie w Salonie. Wówczas pracownik Salonu poczyni odpowiednią notatkę w aplikacji. Wycofanie zgody nie wpływa na zgodność z prawem przetwarzania, którego dokonano na podstawie zgody przed jej wycofaniem. Po rozpoczęciu wykonywania zabiegu dane o stanie zdrowia będą przechowywane dla celów ustalenia, dochodzenia lub obrony przed roszczeniami na podstawie art. 9 ust. 2 lit. f. RODO.

