﻿# MAKIJAŻ & PMU: usuwanie makijażu permanentnego

Zweryfikuj zawartość karty zabiegowej dla zabiegu MAKIJAŻ & PMU: usuwanie makijażu permanentnego
Czy pozostaje Pan/i obecnie pod opieką lekarza lub przyjmuje na stałe jakiekolwiek leki?
Nie, jestem zdrowy/a i nie przyjmuję żadnych leków
Tak, przyjmuję leki okresowo (np. doraźnie lub sezonowo)
Tak, przyjmuję leki na stałe (np. związane z chorobą przewlekłą)
Tak, pozostaję pod opieką lekarza specjalisty
Czy stosuje Pan/i lub w ciągu 2 tygodnii przyjmowała Pan/i jakikolwiek antybiotyk?
Tak    Nie
Czy w ciągu ostatnich 48 godzin przyjmował/a Pan/i:
Nie dotyczy
Aspirynę / ibuprofen
Alkohol
Leki sterydowe (do 6–12 miesięcy po terapii)
Leki antydepresyjne
Inne
Czy w ciągu ostatnich 6 miesięcy przyjmował/a Pan/i izotretynoinę (np. Izotek) lub inne leki przeciwtrądzikowe?
Tak    Nie
Jeśli tak, to jakie leki i kiedy?
Czy lekarz prowadzący wyraził zgodę na zabieg?
Nie dotyczy
Tak
Nie
Czy kiedykolwiek wystąpiła u Pana/i reakcja alergiczna na:
Nie dotyczy
Maści z antybiotykiem
Lateks
Leki
Metale
Farby do włosów / PPDLidokainę
Kosmetyki kolorowe / pigmenty
Inne
Czy w ciągu ostatniego roku przechodził/a Pan/i chemioterapię lub radioterapię?
Tak    Nie
Czy był/a Pan/i hospitalizowany/a w ciągu ostatniego roku?
Tak    Nie
Czy występują u Pana/i poniższe choroby lub stany?
Nie dotyczy
Hemofilia
Nieuregulowana cukrzyca
Zaburzenia pracy serca
Rozrusznik serca
Sztuczne zastawki
Anemia
Nadciśnienie tętnicze
Niedociśnienie tętnicze
Niedociśnienie tętnicze
Zaburzenia krążenia
Długotrwałe krwawienia
Inne
Czy występują u Pana/i inne choroby ogólne?
Nie dotyczy
Zaburzenia tarczycy
Choroby nerek
Choroby wątroby
Wrzody żołądka
Guzy / cysty
GruźlicaHIVToczeń
Astma
Choroby oczu / jaskra / zaćma
Inne
Czy występują poniższe problemy w obrębie oczu lub skóry?
Nie dotyczy
Infekcje oczu
Zespół suchego oka
Opryszczka oka
Łzawienie
Skłonność do siniaków lub krwawień
Inne
Czy wykonywano w obrębie twarzy:
Nie dotyczy
Wypełniacze (kwas hialuronowy)
Przeszczep tłuszczu
Implanty silikonowe / Gore-Tex
Retinoidy miejscowe w ostatnich 6 miesiącach
Kwasy AHA w ostatnich 2 tygodniach
Peeling chemiczny lub laser w ostatnich 6 miesiącach
Inne
Czy ma Pan/i skłonność do blizn przerostowych lub keloidów?
Tak    Nie
Czy ma Pan/i skłonność do krwawień lub obrzęków?
Tak    Nie
Czy choruje Pan/i na choroby autoimmunologiczne?
Nie
Hashimoto
Łuszczyca
Bielactwo
Inne
Czy obecnie występuje opryszczka?
Tak    Nie
Czy jest Pani w ciąży lub karmi piersią?
Nie dotyczy
Tak
Nie
Czy jest Pani w okresie połogu (do 3 miesięcy po porodzie)?
Nie dotyczy
Tak
Nie
Czy wykonywano wcześniej makijaż permanentny?
Tak    Nie
Czy korzystał/a Pan/i z zabiegów medycyny estetycznej w obrębie twarzy?
Nie dotyczy
Toksyna botulinowa
Kwas hialuronowy / wolumetria
Nici PDOZabiegi złuszczające
Laseroterapia
Chirurgia estetyczna
Inne
Czy wykonywano laseroterapię w ciągu ostatnich 2 miesięcy?
Tak    Nie
Jak ocenia Pan/i stan swojej skóry?
Bardzo dobry
Dobry
Do poprawy
Inne
Jak zachowuje się skóra w strefie T?
Sucha
Mieszana / przetłuszczająca się
Normalna
Czy nosi Pan/i soczewki kontaktowe?
Tak    Nie
Czy stosuje Pan/i odżywki do rzęs lub brwi?
Tak    Nie
Czy stosuje Pan/i ochronę przeciwsłoneczną (SPF)?
Tak, codziennie z reaplikacją
Tak, raz dziennie
Tylko latem
Sporadycznie
Nie
Czy planuje Pan/i w najbliższym czasie (za ok. 6 tygodni) wyjazd do miejsca o silnym nasłonecznieniu lub mrozie?
Tak    Nie
Jakiego efektu oczekuje Pan/i po zakończeniu procesu usuwania?
Całkowitego usunięcia pigmentu
Znacznego rozjaśnienia
Przygotowania do nowego makijażu permanentnego
Jestem świadomy/a, że skuteczność i liczba zabiegów zależą od rodzaju pigmentu, głębokości jego wprowadzenia oraz indywidualnych cech skóry.
Tak    Nie
Rozumiem możliwość wystąpienia zaczerwienienia, obrzęku, złuszczania naskórka oraz czasowego pogorszenia wyglądu skóry w trakcie gojenia.
Tak    Nie
Mam świadomość, że proces usuwania jest etapowy i może wymagać kilku sesji zabiegowych.
Tak    Nie
Rozumiem konieczność stosowania się do zaleceń pozabiegowych oraz ochrony przeciwsłonecznej.
Tak    Nie

## Klauzula informacyjna RODO

KLAUZULA INFORMACYJNA DOTYCZĄCA PRZETWARZANIA DANYCH OSOBOWYCHAdministratorem Twoich danych osobowych jest BRAVE EDUCATION SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ z siedzibą w POZNAŃ, przy ul. GŁOGOWSKA 216 (dalej jako „Administrator” lub „my”) Nasze dane kontaktowe:
Jeśli masz jakiekolwiek pytania odnośnie przetwarzania przez nas Twoich danych lub chcesz zrealizować swoje uprawnienia, skontaktuj się z nami na adres firmy lub adres e-mail: redsxiii@gmail.comW jakich celach i na jakich podstawach prawnych będziemy przetwarzać Twoje dane?
CEL: Wykonanie umowy (usługi) lub podjęcie działań przed jej zawarciem i działania związane z wykonaniem umowy – tj. np. wykonanie określonego zabiegu kosmetycznego, realizacja zamówienia produktu, doradztwo w zakresie zasad pielęgnacji, w tym ułożenie Beauty
Planów W tym celu możemy przesyłać na podany przez Ciebie adres e-mail lub numer telefonu informacje związane z umową np. zalecenia pozabiegowe, informacje związane z rejestracją konta w aplikacji, szczegóły dotyczące np. Beauty
Planów
PODSTAWA PRAWNA- w zakresie w jakim przetwarzanie danych jest niezbędne dla realizacji umowy – podstawą prawną będzie wykonanie umowy (podjęcie czynności niezbędnych przed nawiązaniem umowy) (art. 6 ust. 1 lit. b RODO); - w zakresie w jakim z wykonaniem umowy wiązać się będzie realizacja określonych obowiązków wynikających z przepisów prawa (np. podatkowych, księgowych etc.) podstawą prawną będzie stosowny przepis prawa (art. 6 ust. 1 lit. c RODO);- w zakresie w jakim przetwarzanie będzie wykraczać poza to co niezbędne dla zawarcia i wykonania umowy – będziemy przetwarzać dane związane z umową w oparciu o prawnie uzasadniony interes – np. w związku z wysyłaniem zaleceń pozabiegowych, rejestracją w systemie, wysyłaniem informacji dotyczących Beauty
Planu, etc. (art. 6 ust. 1 lit. f RODO); - dane możemy również przetwarzać w zakresie niezbędnym dla ustalenia, dochodzenia lub obroną przed roszczeniami, w tym zgłoszeniem szkód do ubezpieczyciela w oparciu o nasz prawnie uzasadniony interes (art. 6 ust. 1 lit. f RODO).
SPRZECIW: W przypadku przetwarzania przez nas danych w oparciu o prawnie uzasadniony interes masz prawo zgłoszenia sprzeciwu z przyczyn związanych ze swoją szczególną sytuacją. Sprzeciw możesz zgłosić pisząc do nas na adres e-mail redsxiii@gmail.com- dane o stanie zdrowia (np. dane o przyjmowanych lekach, przebytych chorobach, alergiach, ciąży etc. podane przez Ciebie) - w zakresie w jakim jest to niezbędne dla bezpiecznego wykonania zabiegów - u nas są przetwarzane na podstawie wyraźnej zgody na ich przetwarzanie (art. 9 ust. 2 lit. a RODO). Zgoda jest dobrowolna, lecz niezbędna do korzystania z zabiegów kosmetycznych (wykonania umowy).
Do czasu rozpoczęcia zabiegu możesz wycofać zgodę ustnie w Salonie, wówczas pracownik Salonu poczyni odpowiednią notatkę w aplikacji. Wycofanie zgody nie wpływa na zgodność z prawem przetwarzania, którego dokonano na podstawie zgody przed jej wycofaniem.Po rozpoczęciu wykonywania zabiegu dane o stanie zdrowia będą przechowywane dla celów ustalenia, dochodzenia lub obrony przed roszczeniami na podstawie art. 9 ust. 2 lit. f. RODO.
CEL: Odpowiedzi na zapytania
PODSTAWA PRAWNAPodstawą prawną jest nasz prawnie uzasadniony interes polegający na konieczności ustosunkowania się do Twojego zapytania (art. 6 ust. 1 lit. f RODO).
SPRZECIW: W przypadku przetwarzania przez nas danych w oparciu o prawnie uzasadniony interes masz prawo zgłoszenia sprzeciwu z przyczyn związanych ze swoją szczególną sytuacją. Sprzeciw możesz zgłosić pisząc do nas na adres e-mail redsxiii@gmail.comW przypadku, gdy odpowiedzi na zapytania dotyczą umówienia usługi lub zakupu produktu podstawą prawną może być czynność bezpośrednio poprzedzająca zawarcie umowy (art. 6 ust. 1 lit. b RODO).
CEL: Wnioski dotyczące realizacji praw wynikających z RODO lub innych właściwych przepisów
PODSTAWA PRAWNAPodstawą prawną jest nasz obowiązek prawny (art. 6 ust. 1 lit. c RODO) związany z koniecznością realizacji praw osób, których dane dotyczą oraz wykazania prawidłowości wykonania naszych obowiązków.
CEL: Reklamacje
PODSTAWA PRAWNAPodstawą prawną jest nasz lub Twój prawnie uzasadniony interes polegający na komunikacji w związku z daną reklamacją, a następnie w celu obrony przed roszczeniami (art. 6 ust. 1 lit. f RODO).
SPRZECIW: W przypadku przetwarzania przez nas danych w oparciu o prawnie uzasadniony interes masz prawo zgłoszenia sprzeciwu z przyczyn związanych ze swoją szczególną sytuacją. Sprzeciw możesz zgłosić pisząc do nas na adres e-mail redsxiii@gmail.com
Czy podanie Twoich danych jest obowiązkowe?Podanie danych jest dobrowolne. Jednakże niepodanie danych, które są niezbędne dla realizacji określonych powyżej celów może odpowiednio uniemożliwić realizację tych celów, np. niepodanie wymaganych danych będzie skutkować niemożnością wykonania zabiegu, zamówienia produktu itp.
Jak długo przechowujemy Twoje dane?Twoje dane przechowujemy przez następujące okresy w zależności od podstaw prawnych (celów przetwarzania):Wykonanie umowy oraz czynności poprzedzające lub związane z wykonaniem umowy: Twoje dane będą przechowane tak długo jak to jest niezbędne dla realizacji celów dla których zostały zebrane, w tym wykonania umowy (np. przeprowadzenia zabiegu, dostarczenia produktu, odpowiedzi na zapytanie które można zakwalifikować jako czynność poprzedzającą zawarcie umowy) który to okres zostanie wydłużony o stosowny okres przedawnienia roszczeń.Nasze obowiązki prawne: W przypadkach, gdy przetwarzanie Twoich danych służy realizacji obowiązków wynikających z przepisów prawa, będziemy przechowywać Twoje dane przez okresy wskazane w takich przepisach obowiązującego prawa.Twoja zgoda: Twoje dane będą przetwarzane do czasu wycofania udzielonej przez Ciebie zgody na ich przetwarzanie. W przypadkach w których te same dane są przetwarzane również w innych celach, w oparciu o inne podstawy prawne, będziemy mogli je przetwarzać w oparciu o inną niż zgoda właściwą podstawę prawną nawet po wycofaniu przez Ciebie zgody.Prawnie uzasadniony interes: Twoje dane będą przetwarzane do czasu zgłoszenia przez Ciebie skutecznego sprzeciwu względem ich przetwarzania lub do czasu gdy wykażemy istnienie podstaw do ustalenia, dochodzenia lub obrony roszczeń. Oznacza to, że po zgłoszeniu przez Ciebie sprzeciwu dokonamy wyważenia Twoich i naszych interesów. Wówczas nie będziemy już przetwarzać Twoich danych osobowych, chyba że wykażemy istnienie ważnych prawnie uzasadnionych podstaw do przetwarzania, nadrzędnych wobec Twoich interesów, praw i wolności, lub istnienie podstaw do ustalenia, dochodzenia lub obrony roszczeń.
Gdzie są przetwarzane Twoje dane osobowe?Twoje dane osobowe są przetwarzane, w tym przechowywane na terenie Europejskiego Obszaru Gospodarczego.
Komu są przekazywane Twoje dane osobowe?Odbiorcami Twoich danych osobowych są podmioty z nami współpracujące lub dostarczające usługi na naszą rzecz, np. podmioty zajmujące się obsługą systemów IT, archiwizacją dokumentacji, obsługą prawną, rachunkowo - księgową czy też jakiekolwiek inne podmioty, z którymi zawarliśmy umowę powierzenia przetwarzania danych i które są zobowiązane do przetwarzania Twoich danych zgodnie z naszymi wskazówkami. Odbiorcami Twoich danych mogą być także organy nadzorujące przestrzeganie prawa, organ regulacyjne i inne organy administracji publicznej, sądy i organy ścigania (wyłącznie w zakresie wynikającym z obowiązujących przepisów prawa).
Jakie są Twoje prawa?Możesz zwrócić się do nas z określonym żądaniem za pośrednictwem adres e-mail redsxiii@gmail.com lub na nasz adres korespondencyjny. Prosimy wówczas o wskazanie z jakiego prawa i w jakim zakresie chcesz skorzystać. Po wpłynięciu Twojego żądania i ewentualnej weryfikacji Twojej tożsamości podejmiemy w związku z Twoim żądaniem odpowiednie działania.Zgodnie z prawem otrzymasz od nas stosowną odpowiedź tak szybko, jak to możliwe, ale (co do zasady) nie później niż w ciągu miesiąca. W sytuacji, w której Twoje żądanie jest skomplikowane lub prosisz nas jednocześnie o realizację wielu żądań, termin ten może został przedłużony maksymalnie o kolejne dwa miesiące. W takim przypadku zostaniesz poinformowany/poinformowana o takim przedłużeniu terminu.Przysługują Tobie następujące prawa:- prawo dostępu do treści swoich danych, otrzymania ich kopii, żądania ich sprostowania, usunięcia lub ograniczenia ich przetwarzania;- wniesienia sprzeciwu wobec przetwarzania danych osobowych z przyczyn związanych z Twoją szczególną sytuacją w zakresie, w jakim podstawą przetwarzania danych osobowych jest prawnie uzasadniony interes;- przenoszenia danych osobowych w zakresie, w jakim Twoje dane są przetwarzane w celu zawarcia i wykonywania umowy lub na podstawie zgody;- wycofania wyrażonej zgody w dowolnym momencie bez wpływu na legalność przetwarzania dokonanego przed takim wycofaniem. W przypadkach w których te same dane są przetwarzane również w innych celach, w oparciu o inne podstawy prawne, będziemy mogli je przetwarzać w oparciu o inną niż zgoda właściwą podstawę prawną. Wówczas poinformujemy Cię o tym;- Ochrona Twoich danych osobowych jest dla nas priorytetem.
Jeśli jednak uznasz, że przetwarzając Twoje dane osobowe naruszamy RODO, masz prawo wniesienia skargi do Prezesa Urzędu Ochrony Danych Osobowych adres: Stawki 2, 00-193 Warszawa.
ZGODA NA ZABIEG I ZWIĄZANE Z NIM PRZETWARZANIE DANYCH O STANIE ZDROWIANiniejszym oświadczam, że wyrażam świadomą zgodę na wykonanie powyższego zabiegu. Oświadczam, że poinformowano mnie o:1. możliwych powikłaniach,2. powikłaniach nietypowych,3. ryzyku zabiegu i jego następstwach,4. przeciwskazaniach do wykonania zabiegu,5. szczegółowej technice wykonania zabiegu,6. sposobie wykonania zabiegu.Ponadto oświadczam, że miałem/miałam możliwość zadawania wszelkich pytań i uzyskania wyjaśnień jakich oczekiwałem/oczekiwałam. Rozumiem, że pozytywne efekty zabiegu nie są zagwarantowane. Wszystkie informacje przekazane przez kosmetologa są dla mnie w pełni jasne i zrozumiałe. Jednocześnie oświadczam, że udzieliłem/udzieliłam aktualnych i kompletnych informacji co do mojego stanu zdrowia.Mam świadomość, że dla bezpiecznego wykonania zabiegów muszę podać dane o stanie zdrowia (np. dane o alergiach, stosowanych lekach, chorobach, ciąży) wskazane w karcie zabiegowej. Niniejszym składając poniżej podpis wyrażam wyraźną zgodę na ich przetwarzanie w celu wykonania zabiegów.Wycofanie zgody jest możliwe do czasu rozpoczęcia zabiegu ustnie w Salonie. Wówczas pracownik Salonu poczyni odpowiednią notatkę w aplikacji. Wycofanie zgody nie wpływa na zgodność z prawem przetwarzania, którego dokonano na podstawie zgody przed jej wycofaniem. Po rozpoczęciu wykonywania zabiegu dane o stanie zdrowia będą przechowywane dla celów ustalenia, dochodzenia lub obrony przed roszczeniami na podstawie art. 9 ust. 2 lit. f. RODO.

