﻿# Angielski: Karta Zabiegowa Twarz / Facial Treatment Form

Zweryfikuj zawartość karty zabiegowej dla zabiegu Angielski: Karta Zabiegowa Twarz / Facial Treatment Form
Are you currently undergoing any medical treatment?
Yes
No
If yes, please specify or if no, please enter "X".
Are you taking any medications on a regular basis?
Yes
No
If yes, please specify or if no, please enter "X".
Do you have any allergies?
Yes
No
If yes, please specify or if no, please enter "X".
Have you taken or are you currently taking Isotretinoin (Accutane) or any other acne medications/creams within the last 6 months?
Yes
No
If yes, please specify or if no, please enter "X".
When would you like to see results from the treatment?
Immediately
In about a month
In about three monthsI don’t have a specific timeframe
Have you ever experienced any of the following medical conditions?
Cancer
Heart Disease
Cardiovascular Disorders
Blood Vessel Disorders
Lung Disease
Gastrointestinal Disorders
Liver Disease
Urinary Tract Disorders
Metabolic Disorders
Thyroid Disorders
Hormonal Disorders
Nervous System Disorders
Blood and Clotting Disorders
Eye Disorders
None
Have you ever experienced any of the following medical conditions?
Bone and Joint Disorders
Infectious Diseases
Skin Disorders
Psychosomatic Disorders
None
If you have any of the above conditions, please specify the exact condition,
If none, please enter "X".
Have you undergone any invasive cosmetic procedures?
Yes
No
If yes, please specify or if no, please enter "X".
Have you received any aesthetic treatments?
Yes
No
If yes, please specify or if no, please enter "X".
Have you experienced any adverse reactions following any cosmetic or aesthetic procedure, or after using any cosmetic product?
Yes
No
If yes, please specify or if no, please enter "X".
What are your current major skincare concerns?
Sagging skin
Discoloration
Acne scars
Wrinkles
Lack of hydration
Visible capillaries
Acne
Drooping facial contours
Oily T-zone
Skin growths (e.g., fibromas)
Scars
Do you follow your morning skincare routine every day?
Yes
NoI try to
Do you follow your evening skincare routine every day?
Yes
NoI try to
What products do you use in your morning skincare routine? Please check all that apply:
Micellar water
Cleansing oil
Eye makeup remover
Cleansing foam
Cleansing gel
Toner
Exfoliant
Serum
Face and neck cream
Eye creamSPF 50 sunscreen
Foundation
Face masks
Retinol
What products do you use in your evening skincare routine? Please check all that apply:
Micellar water
Cleansing oil
Eye makeup remover
Cleansing foam
Cleansing gel
Toner
Exfoliant
Serum
Face and neck cream
Eye cream
Face masks
Retinol
Do you use skincare products with active ingredients (e.g., Vitamin C, retinol, acids, niacinamide, benzoyl peroxide, hyaluronic acid, peptides, extracts, etc.)?
Yes
No
If yes, please specify or if no, please enter "X".
Do you use sun protection?
Yes, every morning and reapply during the day
Yes, but only once a day
Yes, but only in the summer
Occasionally
No
How do you rate the current condition of your skin?
Very good
Good
Needs improvement
Do you smoke cigarettes?
Yes
No
If yes, how many per day or if no, please enter "X".
Do you have any prostheses, implants, a pacemaker, or an intrauterine device (IUD)?
Yes
No
If yes, please specify or if no, please enter "X".
How much water do you drink daily?
More than 1 liter1 to 1.5 liters1.5 to 2 liters2 to 2.5 liters
Less than 2.5 liters
Have you undergone hormonal treatment?
Yes
No
If yes, please specify when or if no, please enter "X".
How many hours do you usually sleep?
Less than 7 hours7 to 8 hours8 to 9 hours
More than 9 hours
Do you spend more time indoors or outdoors during the day?
Air-conditioned rooms
Non-air-conditioned rooms
Outdoors
Do you use a tanning bed?
Yes
No
If yes, please specify how often and when the last time, or if no, please enter “X”.
Are you pregnant?
Yes
No
Not applicable
Are you breastfeeding?
Yes
No
Not applicable
Do you experience any digestive or intestinal issues?
Yes
No
If yes, please specify or if no, please enter "X".
28.
Do you engage in regular physical activity?
If so, please indicate the frequency:
0 times per week1-2 times per week3-4 times per week
More than 5 times per week
If you engage in physical activity, what type do you primarily participate in?
Not applicable
Strength training
Cardio
Stretching/Yoga/Pilates
Other
Do you take any dietary supplements? Please choose from the following options:
Vitamin DVitamin AVitamin EB vitamins
Vitamin COmega 3Iron
Magnesium
Biotin
CollagenI do not take any supplements
If you take any supplements not mentioned above, please list them.
If not, please enter "X".
Please check all that apply to your diet:
Vegetarian diet
Vegan dietI include meat in my dietI avoid sweets and fast foodI consume a large amount of sweets and fast food
Diet rich in fruits and vegetables
Diet low in fruits and vegetables
High-protein diet
Low-calorie diet
High-calorie diet
Ketogenic diet
Traditional Polish cuisineI do not pay special attention to my diet
Diet rich in gluten (pasta, bread, cakes)
Additional information/notes.
If none, please enter "X"
Wyrażam zgodę na przetwarzanie moich danych dotyczących zdrowia na potrzeby przeprowadzenia zabiegu.

## Klauzula informacyjna RODO

KLAUZULA INFORMACYJNA DOTYCZĄCA PRZETWARZANIA DANYCH OSOBOWYCHAdministratorem Twoich danych osobowych jest BRAVE EDUCATION SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ z siedzibą w POZNAŃ, przy ul. GŁOGOWSKA 216 (dalej jako „Administrator” lub „my”) Nasze dane kontaktowe:
Jeśli masz jakiekolwiek pytania odnośnie przetwarzania przez nas Twoich danych lub chcesz zrealizować swoje uprawnienia, skontaktuj się z nami na adres firmy lub adres e-mail: redsxiii@gmail.comW jakich celach i na jakich podstawach prawnych będziemy przetwarzać Twoje dane?
CEL: Wykonanie umowy (usługi) lub podjęcie działań przed jej zawarciem i działania związane z wykonaniem umowy – tj. np. wykonanie określonego zabiegu kosmetycznego, realizacja zamówienia produktu, doradztwo w zakresie zasad pielęgnacji, w tym ułożenie Beauty
Planów W tym celu możemy przesyłać na podany przez Ciebie adres e-mail lub numer telefonu informacje związane z umową np. zalecenia pozabiegowe, informacje związane z rejestracją konta w aplikacji, szczegóły dotyczące np. Beauty
Planów
PODSTAWA PRAWNA- w zakresie w jakim przetwarzanie danych jest niezbędne dla realizacji umowy – podstawą prawną będzie wykonanie umowy (podjęcie czynności niezbędnych przed nawiązaniem umowy) (art. 6 ust. 1 lit. b RODO); - w zakresie w jakim z wykonaniem umowy wiązać się będzie realizacja określonych obowiązków wynikających z przepisów prawa (np. podatkowych, księgowych etc.) podstawą prawną będzie stosowny przepis prawa (art. 6 ust. 1 lit. c RODO);- w zakresie w jakim przetwarzanie będzie wykraczać poza to co niezbędne dla zawarcia i wykonania umowy – będziemy przetwarzać dane związane z umową w oparciu o prawnie uzasadniony interes – np. w związku z wysyłaniem zaleceń pozabiegowych, rejestracją w systemie, wysyłaniem informacji dotyczących Beauty
Planu, etc. (art. 6 ust. 1 lit. f RODO); - dane możemy również przetwarzać w zakresie niezbędnym dla ustalenia, dochodzenia lub obroną przed roszczeniami, w tym zgłoszeniem szkód do ubezpieczyciela w oparciu o nasz prawnie uzasadniony interes (art. 6 ust. 1 lit. f RODO).
SPRZECIW: W przypadku przetwarzania przez nas danych w oparciu o prawnie uzasadniony interes masz prawo zgłoszenia sprzeciwu z przyczyn związanych ze swoją szczególną sytuacją. Sprzeciw możesz zgłosić pisząc do nas na adres e-mail redsxiii@gmail.com- dane o stanie zdrowia (np. dane o przyjmowanych lekach, przebytych chorobach, alergiach, ciąży etc. podane przez Ciebie) - w zakresie w jakim jest to niezbędne dla bezpiecznego wykonania zabiegów - u nas są przetwarzane na podstawie wyraźnej zgody na ich przetwarzanie (art. 9 ust. 2 lit. a RODO). Zgoda jest dobrowolna, lecz niezbędna do korzystania z zabiegów kosmetycznych (wykonania umowy).
Do czasu rozpoczęcia zabiegu możesz wycofać zgodę ustnie w Salonie, wówczas pracownik Salonu poczyni odpowiednią notatkę w aplikacji. Wycofanie zgody nie wpływa na zgodność z prawem przetwarzania, którego dokonano na podstawie zgody przed jej wycofaniem.Po rozpoczęciu wykonywania zabiegu dane o stanie zdrowia będą przechowywane dla celów ustalenia, dochodzenia lub obrony przed roszczeniami na podstawie art. 9 ust. 2 lit. f. RODO.
CEL: Odpowiedzi na zapytania
PODSTAWA PRAWNAPodstawą prawną jest nasz prawnie uzasadniony interes polegający na konieczności ustosunkowania się do Twojego zapytania (art. 6 ust. 1 lit. f RODO).
SPRZECIW: W przypadku przetwarzania przez nas danych w oparciu o prawnie uzasadniony interes masz prawo zgłoszenia sprzeciwu z przyczyn związanych ze swoją szczególną sytuacją. Sprzeciw możesz zgłosić pisząc do nas na adres e-mail redsxiii@gmail.comW przypadku, gdy odpowiedzi na zapytania dotyczą umówienia usługi lub zakupu produktu podstawą prawną może być czynność bezpośrednio poprzedzająca zawarcie umowy (art. 6 ust. 1 lit. b RODO).
CEL: Wnioski dotyczące realizacji praw wynikających z RODO lub innych właściwych przepisów
PODSTAWA PRAWNAPodstawą prawną jest nasz obowiązek prawny (art. 6 ust. 1 lit. c RODO) związany z koniecznością realizacji praw osób, których dane dotyczą oraz wykazania prawidłowości wykonania naszych obowiązków.
CEL: Reklamacje
PODSTAWA PRAWNAPodstawą prawną jest nasz lub Twój prawnie uzasadniony interes polegający na komunikacji w związku z daną reklamacją, a następnie w celu obrony przed roszczeniami (art. 6 ust. 1 lit. f RODO).
SPRZECIW: W przypadku przetwarzania przez nas danych w oparciu o prawnie uzasadniony interes masz prawo zgłoszenia sprzeciwu z przyczyn związanych ze swoją szczególną sytuacją. Sprzeciw możesz zgłosić pisząc do nas na adres e-mail redsxiii@gmail.com
Czy podanie Twoich danych jest obowiązkowe?Podanie danych jest dobrowolne. Jednakże niepodanie danych, które są niezbędne dla realizacji określonych powyżej celów może odpowiednio uniemożliwić realizację tych celów, np. niepodanie wymaganych danych będzie skutkować niemożnością wykonania zabiegu, zamówienia produktu itp.
Jak długo przechowujemy Twoje dane?Twoje dane przechowujemy przez następujące okresy w zależności od podstaw prawnych (celów przetwarzania):Wykonanie umowy oraz czynności poprzedzające lub związane z wykonaniem umowy: Twoje dane będą przechowane tak długo jak to jest niezbędne dla realizacji celów dla których zostały zebrane, w tym wykonania umowy (np. przeprowadzenia zabiegu, dostarczenia produktu, odpowiedzi na zapytanie które można zakwalifikować jako czynność poprzedzającą zawarcie umowy) który to okres zostanie wydłużony o stosowny okres przedawnienia roszczeń.Nasze obowiązki prawne: W przypadkach, gdy przetwarzanie Twoich danych służy realizacji obowiązków wynikających z przepisów prawa, będziemy przechowywać Twoje dane przez okresy wskazane w takich przepisach obowiązującego prawa.Twoja zgoda: Twoje dane będą przetwarzane do czasu wycofania udzielonej przez Ciebie zgody na ich przetwarzanie. W przypadkach w których te same dane są przetwarzane również w innych celach, w oparciu o inne podstawy prawne, będziemy mogli je przetwarzać w oparciu o inną niż zgoda właściwą podstawę prawną nawet po wycofaniu przez Ciebie zgody.Prawnie uzasadniony interes: Twoje dane będą przetwarzane do czasu zgłoszenia przez Ciebie skutecznego sprzeciwu względem ich przetwarzania lub do czasu gdy wykażemy istnienie podstaw do ustalenia, dochodzenia lub obrony roszczeń. Oznacza to, że po zgłoszeniu przez Ciebie sprzeciwu dokonamy wyważenia Twoich i naszych interesów. Wówczas nie będziemy już przetwarzać Twoich danych osobowych, chyba że wykażemy istnienie ważnych prawnie uzasadnionych podstaw do przetwarzania, nadrzędnych wobec Twoich interesów, praw i wolności, lub istnienie podstaw do ustalenia, dochodzenia lub obrony roszczeń.
Gdzie są przetwarzane Twoje dane osobowe?Twoje dane osobowe są przetwarzane, w tym przechowywane na terenie Europejskiego Obszaru Gospodarczego.
Komu są przekazywane Twoje dane osobowe?Odbiorcami Twoich danych osobowych są podmioty z nami współpracujące lub dostarczające usługi na naszą rzecz, np. podmioty zajmujące się obsługą systemów IT, archiwizacją dokumentacji, obsługą prawną, rachunkowo - księgową czy też jakiekolwiek inne podmioty, z którymi zawarliśmy umowę powierzenia przetwarzania danych i które są zobowiązane do przetwarzania Twoich danych zgodnie z naszymi wskazówkami. Odbiorcami Twoich danych mogą być także organy nadzorujące przestrzeganie prawa, organ regulacyjne i inne organy administracji publicznej, sądy i organy ścigania (wyłącznie w zakresie wynikającym z obowiązujących przepisów prawa).
Jakie są Twoje prawa?Możesz zwrócić się do nas z określonym żądaniem za pośrednictwem adres e-mail redsxiii@gmail.com lub na nasz adres korespondencyjny. Prosimy wówczas o wskazanie z jakiego prawa i w jakim zakresie chcesz skorzystać. Po wpłynięciu Twojego żądania i ewentualnej weryfikacji Twojej tożsamości podejmiemy w związku z Twoim żądaniem odpowiednie działania.Zgodnie z prawem otrzymasz od nas stosowną odpowiedź tak szybko, jak to możliwe, ale (co do zasady) nie później niż w ciągu miesiąca. W sytuacji, w której Twoje żądanie jest skomplikowane lub prosisz nas jednocześnie o realizację wielu żądań, termin ten może został przedłużony maksymalnie o kolejne dwa miesiące. W takim przypadku zostaniesz poinformowany/poinformowana o takim przedłużeniu terminu.Przysługują Tobie następujące prawa:- prawo dostępu do treści swoich danych, otrzymania ich kopii, żądania ich sprostowania, usunięcia lub ograniczenia ich przetwarzania;- wniesienia sprzeciwu wobec przetwarzania danych osobowych z przyczyn związanych z Twoją szczególną sytuacją w zakresie, w jakim podstawą przetwarzania danych osobowych jest prawnie uzasadniony interes;- przenoszenia danych osobowych w zakresie, w jakim Twoje dane są przetwarzane w celu zawarcia i wykonywania umowy lub na podstawie zgody;- wycofania wyrażonej zgody w dowolnym momencie bez wpływu na legalność przetwarzania dokonanego przed takim wycofaniem. W przypadkach w których te same dane są przetwarzane również w innych celach, w oparciu o inne podstawy prawne, będziemy mogli je przetwarzać w oparciu o inną niż zgoda właściwą podstawę prawną. Wówczas poinformujemy Cię o tym;- Ochrona Twoich danych osobowych jest dla nas priorytetem.
Jeśli jednak uznasz, że przetwarzając Twoje dane osobowe naruszamy RODO, masz prawo wniesienia skargi do Prezesa Urzędu Ochrony Danych Osobowych adres: Stawki 2, 00-193 Warszawa.
ZGODA NA ZABIEG I ZWIĄZANE Z NIM PRZETWARZANIE DANYCH O STANIE ZDROWIANiniejszym oświadczam, że wyrażam świadomą zgodę na wykonanie powyższego zabiegu. Oświadczam, że poinformowano mnie o:1. możliwych powikłaniach,2. powikłaniach nietypowych,3. ryzyku zabiegu i jego następstwach,4. przeciwskazaniach do wykonania zabiegu,5. szczegółowej technice wykonania zabiegu,6. sposobie wykonania zabiegu.Ponadto oświadczam, że miałem/miałam możliwość zadawania wszelkich pytań i uzyskania wyjaśnień jakich oczekiwałem/oczekiwałam. Rozumiem, że pozytywne efekty zabiegu nie są zagwarantowane. Wszystkie informacje przekazane przez kosmetologa są dla mnie w pełni jasne i zrozumiałe. Jednocześnie oświadczam, że udzieliłem/udzieliłam aktualnych i kompletnych informacji co do mojego stanu zdrowia.Mam świadomość, że dla bezpiecznego wykonania zabiegów muszę podać dane o stanie zdrowia (np. dane o alergiach, stosowanych lekach, chorobach, ciąży) wskazane w karcie zabiegowej. Niniejszym składając poniżej podpis wyrażam wyraźną zgodę na ich przetwarzanie w celu wykonania zabiegów.Wycofanie zgody jest możliwe do czasu rozpoczęcia zabiegu ustnie w Salonie. Wówczas pracownik Salonu poczyni odpowiednią notatkę w aplikacji. Wycofanie zgody nie wpływa na zgodność z prawem przetwarzania, którego dokonano na podstawie zgody przed jej wycofaniem. Po rozpoczęciu wykonywania zabiegu dane o stanie zdrowia będą przechowywane dla celów ustalenia, dochodzenia lub obrony przed roszczeniami na podstawie art. 9 ust. 2 lit. f. RODO.

