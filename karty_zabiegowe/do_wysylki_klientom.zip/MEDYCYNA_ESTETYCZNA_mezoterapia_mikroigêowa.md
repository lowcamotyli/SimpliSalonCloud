﻿# MEDYCYNA ESTETYCZNA: mezoterapia mikroigłowa

Zweryfikuj zawartość karty zabiegowej dla zabiegu MEDYCYNA ESTETYCZNA: mezoterapia mikroigłowa
Czy pozostaje Pan/i obecnie pod opieką lekarza lub przyjmuje na stałe jakiekolwiek leki?
Nie, jestem zdrowy/a i nie przyjmuję żadnych leków
Tak, przyjmuję leki okresowo (np. doraźnie lub sezonowo)
Tak, przyjmuję leki na stałe (np. związane z chorobą przewlekłą)
Tak, pozostaję pod opieką lekarza specjalisty
Jeśli pozostaje Pan/i pod opieką lekarza, proszę zaznaczyć, czego dotyczy leczenie:
Nie dotyczy
Choroby serca / układu krążenia
Cukrzyca / zaburzenia metaboliczne
Choroby tarczycy / hormonalne
Choroby autoimmunologiczne (np. Hashimoto, RZS, toczeń)
Choroby skóry (np. trądzik, łuszczyca, AZS, opryszczka)
Choroby neurologiczne / psychosomatyczne
Choroby nowotworowe (obecne lub przebyte)
Czy ma Pan/i zdiagnozowane choroby lub dolegliwości, o których warto nas poinformować przed planowanym zabiegiem?
Nie, nie mam żadnych chorób przewlekłych
Choroby układu krążenia
Choroby układu oddechowego
Choroby układu pokarmowego / wątroby / nerek
Zaburzenia krzepnięcia krwi
Choroby zakaźne
Choroby układu kostnego lub stawów
Inne
Czy zauważył/a Pan/i u siebie reakcje alergiczne lub nadwrażliwość na określone substancje?
Nie, nie mam żadnych alergii
Lidokaina / środki znieczulające
Lateks
Nikiel / metale
Leki (np. przeciwbólowe, antybiotyki)
Kosmetyki / składniki aktywne
Inne
Czy posiada Pan/i rozrusznik serca, implanty lub wypełniacze?
Nie
Rozrusznik serca
Implanty metalowe / stomatologiczne
Wypełniacze
Czy stosuje Pan/i suplementację?
Nie stosuję suplementacji
Tak, regularnie
Tak, sporadycznie
Jakie suplementy Pan/i przyjmuje?
Witaminy ogólne (multiwitamina)
Witamina D3Witamina CWitamina EBiotyna / suplementy na włosy, skórę, paznokcie
Cynk / selen / miedź
Kolagen / kwas hialuronowy
Kwasy omega-3 / omega-6Magnez / wapń
Probiotyki
Zioła i adaptogeny (np. żeń-szeń, ashwagandha)
Czy zdarza się u Pana/i opryszczka (tzw. „zimno”)?
Nie, nigdy nie miałem/am opryszczki
Tak, występuje sporadycznie
Tak, nawraca regularnie (kilka razy w roku)
Czy ma Pan/i skłonność do bliznowców?
Tak    Nie
Czy jest Pani w ciąży lub karmi piersią?
Nie dotyczy
Tak - ciąża
Tak - karmienie
Nie
Czy stosuje Pan/i kosmetyki lub produkty z substancjami aktywnymi?
Nie
Retinol / pochodne wit. AKwasy (AHA / BHA / PHA)
Witamina CPeptydy / niacynamid
Czy w ciągu ostatnich 14 dni wykonywano jakiekolwiek zabiegi lub procedury na skórze w miejscu, które ma być teraz poddane zabiegowi?
Nie miałem/am wykonywanych żadnych zabiegów w tym obszarze
Peeling kawitacyjny
Mikrodermabrazja
Peeling chemiczny lub kwasowy
Zabieg z retinolem
Oczyszczanie manualne lub wodorowe
Mezoterapia igłowa
Dermapen / mezoterapia mikroigłowa
Zabieg laserowy
Radiofrekwencja mikroigłowa
Wypełniacze (np. kwas hialuronowy)
Toksyna botulinowa (botoks)
Nici PDO lub liftingujące
Osocze bogatopłytkowe lub fibryna (PRP / PRF)
Inne
Czy korzystał/a Pan/i wcześniej z zabiegów medycyny estetycznej?
Nie, to mój pierwszy zabieg
Tak, pojedyncze zabiegi w przeszłości
Tak, regularnie korzystam z zabiegów
Jeśli miała Pan/i styczność z zabiegami, proszę określić jakie typy zabiegów Pan/i wykonywał/a:
Mezoterapia igłowa /  Mezoterapia mikroigłowa
Wypełniacze
Toksyna botulinowa (botoks)
Stymulatory tkankowe / biorewitalizacja
Nici PDO / liftingujące
Zabiegi laserowe
Peelingi chemiczne
Osocze bogatopłytkowe / fibryna (PRP / PRF)
Radiofrekwencja mikroigłowa
Kiedy ostatni raz wykonywano którykolwiek z powyższych zabiegów?
W ciągu ostatnich 2 tygodni2–6 tygodni temu1–3 miesiące temu
Ponad 3 miesiące temu
Ponad pół roku temu
Ile litrów wody pije Pan/i w ciągu dnia?
<1l1l - 1,5l1,5l - 2l2l - 2,5l>2,5l
Czy pali Pan/i papierosy?
Nie dotyczy
Palę papierosy tradycyjne
Korzystam z e-papierosów / podgrzewaczy tytoniu
Okazjonalnie palę (np. towarzysko)
Czy w ciągu ostatnich 24 godzin spożywał/a Pan/i alkohol?
Nie, nie spożywałem/am alkoholu
Tak, w niewielkiej ilości (np. kieliszek wina, drink)
Tak, w większej ilości (więcej niż 2 porcje alkoholu)
Czy spożywa Pan/i alkohol regularnie?
Nie, tylko okazjonalnie
Tak, kilka razy w miesiącu
Tak, kilka razy w tygodniu
Tak, codziennie
Czy stosuje Pan/i ochronę przeciwsłoneczną (SPF)?
Nie
Tak, codziennie
Czasami
Proszę określić swoją pielęgnację poranną:
Oczyszczanie (żel/pianka/micelarna)
Tonizacja / esencja
Serum (np. antyoksydacyjne, nawilżające)
Krem na dzień (nawilżający/odżywczy)
Ochrona przeciwsłoneczna (SPF)
Makijaż (ostatni etap)
Jak wygląda Pana/i pielęgnacja poranna? Prosimy o zaznaczenie produktów, których Pan/i używa.
Brak pielęgnacji porannej
Oczyszczanie twarzy (żel/pianka/micelarna)
Tonik / hydrolat / esencja
Serum nawilżające (np. kwas hialuronowy)
Serum antyoksydacyjne (np. witamina C, resweratrol, ferulowy)
Serum matujące/regulujące sebum (np. niacynamid, cynk)
Serum specjalistyczne (np. przeciwtrądzikowe, przeciw przebarwieniom)
Krem na dzień (nawilżający, odżywczy, matujący)
Krem pod oczy
Ochrona przeciwsłoneczna SPFMakijaż (podkład, puder, BB/CC)
Jak wygląda Pana/i pielęgnacja wieczorna? Prosimy o zaznaczenie produktów, których Pan/i używa.
Brak pielęgnacji wieczornej
Demakijaż (płyn micelarny, mleczko, olejek)
Oczyszczanie (żel/pianka)
Oczyszczanie 2-etapowe (olejek + żel/pianka)
Tonik / esencja
Serum nawilżające (np. kwas hialuronowy)
Serum z kwasami (np. AHA, BHA, PHA)
Serum z retinolem / retinoidami
Serum specjalistyczne (np. przeciw przebarwieniom, na trądzik, na naczynka)
Krem na noc (nawilżający, odżywczy, regenerujący)
Krem pod oczy
Olejek do twarzy
Maska nocna / krem-maska

## Klauzula informacyjna RODO

KLAUZULA INFORMACYJNA DOTYCZĄCA PRZETWARZANIA DANYCH OSOBOWYCHAdministratorem Twoich danych osobowych jest BRAVE EDUCATION SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ z siedzibą w POZNAŃ, przy ul. GŁOGOWSKA 216 (dalej jako „Administrator” lub „my”) Nasze dane kontaktowe:
Jeśli masz jakiekolwiek pytania odnośnie przetwarzania przez nas Twoich danych lub chcesz zrealizować swoje uprawnienia, skontaktuj się z nami na adres firmy lub adres e-mail: redsxiii@gmail.comW jakich celach i na jakich podstawach prawnych będziemy przetwarzać Twoje dane?
CEL: Wykonanie umowy (usługi) lub podjęcie działań przed jej zawarciem i działania związane z wykonaniem umowy – tj. np. wykonanie określonego zabiegu kosmetycznego, realizacja zamówienia produktu, doradztwo w zakresie zasad pielęgnacji, w tym ułożenie Beauty
Planów W tym celu możemy przesyłać na podany przez Ciebie adres e-mail lub numer telefonu informacje związane z umową np. zalecenia pozabiegowe, informacje związane z rejestracją konta w aplikacji, szczegóły dotyczące np. Beauty
Planów
PODSTAWA PRAWNA- w zakresie w jakim przetwarzanie danych jest niezbędne dla realizacji umowy – podstawą prawną będzie wykonanie umowy (podjęcie czynności niezbędnych przed nawiązaniem umowy) (art. 6 ust. 1 lit. b RODO); - w zakresie w jakim z wykonaniem umowy wiązać się będzie realizacja określonych obowiązków wynikających z przepisów prawa (np. podatkowych, księgowych etc.) podstawą prawną będzie stosowny przepis prawa (art. 6 ust. 1 lit. c RODO);- w zakresie w jakim przetwarzanie będzie wykraczać poza to co niezbędne dla zawarcia i wykonania umowy – będziemy przetwarzać dane związane z umową w oparciu o prawnie uzasadniony interes – np. w związku z wysyłaniem zaleceń pozabiegowych, rejestracją w systemie, wysyłaniem informacji dotyczących Beauty
Planu, etc. (art. 6 ust. 1 lit. f RODO); - dane możemy również przetwarzać w zakresie niezbędnym dla ustalenia, dochodzenia lub obroną przed roszczeniami, w tym zgłoszeniem szkód do ubezpieczyciela w oparciu o nasz prawnie uzasadniony interes (art. 6 ust. 1 lit. f RODO).
SPRZECIW: W przypadku przetwarzania przez nas danych w oparciu o prawnie uzasadniony interes masz prawo zgłoszenia sprzeciwu z przyczyn związanych ze swoją szczególną sytuacją. Sprzeciw możesz zgłosić pisząc do nas na adres e-mail redsxiii@gmail.com- dane o stanie zdrowia (np. dane o przyjmowanych lekach, przebytych chorobach, alergiach, ciąży etc. podane przez Ciebie) - w zakresie w jakim jest to niezbędne dla bezpiecznego wykonania zabiegów - u nas są przetwarzane na podstawie wyraźnej zgody na ich przetwarzanie (art. 9 ust. 2 lit. a RODO). Zgoda jest dobrowolna, lecz niezbędna do korzystania z zabiegów kosmetycznych (wykonania umowy).
Do czasu rozpoczęcia zabiegu możesz wycofać zgodę ustnie w Salonie, wówczas pracownik Salonu poczyni odpowiednią notatkę w aplikacji. Wycofanie zgody nie wpływa na zgodność z prawem przetwarzania, którego dokonano na podstawie zgody przed jej wycofaniem.Po rozpoczęciu wykonywania zabiegu dane o stanie zdrowia będą przechowywane dla celów ustalenia, dochodzenia lub obrony przed roszczeniami na podstawie art. 9 ust. 2 lit. f. RODO.
CEL: Odpowiedzi na zapytania
PODSTAWA PRAWNAPodstawą prawną jest nasz prawnie uzasadniony interes polegający na konieczności ustosunkowania się do Twojego zapytania (art. 6 ust. 1 lit. f RODO).
SPRZECIW: W przypadku przetwarzania przez nas danych w oparciu o prawnie uzasadniony interes masz prawo zgłoszenia sprzeciwu z przyczyn związanych ze swoją szczególną sytuacją. Sprzeciw możesz zgłosić pisząc do nas na adres e-mail redsxiii@gmail.comW przypadku, gdy odpowiedzi na zapytania dotyczą umówienia usługi lub zakupu produktu podstawą prawną może być czynność bezpośrednio poprzedzająca zawarcie umowy (art. 6 ust. 1 lit. b RODO).
CEL: Wnioski dotyczące realizacji praw wynikających z RODO lub innych właściwych przepisów
PODSTAWA PRAWNAPodstawą prawną jest nasz obowiązek prawny (art. 6 ust. 1 lit. c RODO) związany z koniecznością realizacji praw osób, których dane dotyczą oraz wykazania prawidłowości wykonania naszych obowiązków.
CEL: Reklamacje
PODSTAWA PRAWNAPodstawą prawną jest nasz lub Twój prawnie uzasadniony interes polegający na komunikacji w związku z daną reklamacją, a następnie w celu obrony przed roszczeniami (art. 6 ust. 1 lit. f RODO).
SPRZECIW: W przypadku przetwarzania przez nas danych w oparciu o prawnie uzasadniony interes masz prawo zgłoszenia sprzeciwu z przyczyn związanych ze swoją szczególną sytuacją. Sprzeciw możesz zgłosić pisząc do nas na adres e-mail redsxiii@gmail.com
Czy podanie Twoich danych jest obowiązkowe?Podanie danych jest dobrowolne. Jednakże niepodanie danych, które są niezbędne dla realizacji określonych powyżej celów może odpowiednio uniemożliwić realizację tych celów, np. niepodanie wymaganych danych będzie skutkować niemożnością wykonania zabiegu, zamówienia produktu itp.
Jak długo przechowujemy Twoje dane?Twoje dane przechowujemy przez następujące okresy w zależności od podstaw prawnych (celów przetwarzania):Wykonanie umowy oraz czynności poprzedzające lub związane z wykonaniem umowy: Twoje dane będą przechowane tak długo jak to jest niezbędne dla realizacji celów dla których zostały zebrane, w tym wykonania umowy (np. przeprowadzenia zabiegu, dostarczenia produktu, odpowiedzi na zapytanie które można zakwalifikować jako czynność poprzedzającą zawarcie umowy) który to okres zostanie wydłużony o stosowny okres przedawnienia roszczeń.Nasze obowiązki prawne: W przypadkach, gdy przetwarzanie Twoich danych służy realizacji obowiązków wynikających z przepisów prawa, będziemy przechowywać Twoje dane przez okresy wskazane w takich przepisach obowiązującego prawa.Twoja zgoda: Twoje dane będą przetwarzane do czasu wycofania udzielonej przez Ciebie zgody na ich przetwarzanie. W przypadkach w których te same dane są przetwarzane również w innych celach, w oparciu o inne podstawy prawne, będziemy mogli je przetwarzać w oparciu o inną niż zgoda właściwą podstawę prawną nawet po wycofaniu przez Ciebie zgody.Prawnie uzasadniony interes: Twoje dane będą przetwarzane do czasu zgłoszenia przez Ciebie skutecznego sprzeciwu względem ich przetwarzania lub do czasu gdy wykażemy istnienie podstaw do ustalenia, dochodzenia lub obrony roszczeń. Oznacza to, że po zgłoszeniu przez Ciebie sprzeciwu dokonamy wyważenia Twoich i naszych interesów. Wówczas nie będziemy już przetwarzać Twoich danych osobowych, chyba że wykażemy istnienie ważnych prawnie uzasadnionych podstaw do przetwarzania, nadrzędnych wobec Twoich interesów, praw i wolności, lub istnienie podstaw do ustalenia, dochodzenia lub obrony roszczeń.
Gdzie są przetwarzane Twoje dane osobowe?Twoje dane osobowe są przetwarzane, w tym przechowywane na terenie Europejskiego Obszaru Gospodarczego.
Komu są przekazywane Twoje dane osobowe?Odbiorcami Twoich danych osobowych są podmioty z nami współpracujące lub dostarczające usługi na naszą rzecz, np. podmioty zajmujące się obsługą systemów IT, archiwizacją dokumentacji, obsługą prawną, rachunkowo - księgową czy też jakiekolwiek inne podmioty, z którymi zawarliśmy umowę powierzenia przetwarzania danych i które są zobowiązane do przetwarzania Twoich danych zgodnie z naszymi wskazówkami. Odbiorcami Twoich danych mogą być także organy nadzorujące przestrzeganie prawa, organ regulacyjne i inne organy administracji publicznej, sądy i organy ścigania (wyłącznie w zakresie wynikającym z obowiązujących przepisów prawa).
Jakie są Twoje prawa?Możesz zwrócić się do nas z określonym żądaniem za pośrednictwem adres e-mail redsxiii@gmail.com lub na nasz adres korespondencyjny. Prosimy wówczas o wskazanie z jakiego prawa i w jakim zakresie chcesz skorzystać. Po wpłynięciu Twojego żądania i ewentualnej weryfikacji Twojej tożsamości podejmiemy w związku z Twoim żądaniem odpowiednie działania.Zgodnie z prawem otrzymasz od nas stosowną odpowiedź tak szybko, jak to możliwe, ale (co do zasady) nie później niż w ciągu miesiąca. W sytuacji, w której Twoje żądanie jest skomplikowane lub prosisz nas jednocześnie o realizację wielu żądań, termin ten może został przedłużony maksymalnie o kolejne dwa miesiące. W takim przypadku zostaniesz poinformowany/poinformowana o takim przedłużeniu terminu.Przysługują Tobie następujące prawa:- prawo dostępu do treści swoich danych, otrzymania ich kopii, żądania ich sprostowania, usunięcia lub ograniczenia ich przetwarzania;- wniesienia sprzeciwu wobec przetwarzania danych osobowych z przyczyn związanych z Twoją szczególną sytuacją w zakresie, w jakim podstawą przetwarzania danych osobowych jest prawnie uzasadniony interes;- przenoszenia danych osobowych w zakresie, w jakim Twoje dane są przetwarzane w celu zawarcia i wykonywania umowy lub na podstawie zgody;- wycofania wyrażonej zgody w dowolnym momencie bez wpływu na legalność przetwarzania dokonanego przed takim wycofaniem. W przypadkach w których te same dane są przetwarzane również w innych celach, w oparciu o inne podstawy prawne, będziemy mogli je przetwarzać w oparciu o inną niż zgoda właściwą podstawę prawną. Wówczas poinformujemy Cię o tym;- Ochrona Twoich danych osobowych jest dla nas priorytetem.
Jeśli jednak uznasz, że przetwarzając Twoje dane osobowe naruszamy RODO, masz prawo wniesienia skargi do Prezesa Urzędu Ochrony Danych Osobowych adres: Stawki 2, 00-193 Warszawa.
ZGODA NA ZABIEG I ZWIĄZANE Z NIM PRZETWARZANIE DANYCH O STANIE ZDROWIANiniejszym oświadczam, że wyrażam świadomą zgodę na wykonanie powyższego zabiegu. Oświadczam, że poinformowano mnie o:1. możliwych powikłaniach,2. powikłaniach nietypowych,3. ryzyku zabiegu i jego następstwach,4. przeciwskazaniach do wykonania zabiegu,5. szczegółowej technice wykonania zabiegu,6. sposobie wykonania zabiegu.Ponadto oświadczam, że miałem/miałam możliwość zadawania wszelkich pytań i uzyskania wyjaśnień jakich oczekiwałem/oczekiwałam. Rozumiem, że pozytywne efekty zabiegu nie są zagwarantowane. Wszystkie informacje przekazane przez kosmetologa są dla mnie w pełni jasne i zrozumiałe. Jednocześnie oświadczam, że udzieliłem/udzieliłam aktualnych i kompletnych informacji co do mojego stanu zdrowia.Mam świadomość, że dla bezpiecznego wykonania zabiegów muszę podać dane o stanie zdrowia (np. dane o alergiach, stosowanych lekach, chorobach, ciąży) wskazane w karcie zabiegowej. Niniejszym składając poniżej podpis wyrażam wyraźną zgodę na ich przetwarzanie w celu wykonania zabiegów.Wycofanie zgody jest możliwe do czasu rozpoczęcia zabiegu ustnie w Salonie. Wówczas pracownik Salonu poczyni odpowiednią notatkę w aplikacji. Wycofanie zgody nie wpływa na zgodność z prawem przetwarzania, którego dokonano na podstawie zgody przed jej wycofaniem. Po rozpoczęciu wykonywania zabiegu dane o stanie zdrowia będą przechowywane dla celów ustalenia, dochodzenia lub obrony przed roszczeniami na podstawie art. 9 ust. 2 lit. f. RODO.

