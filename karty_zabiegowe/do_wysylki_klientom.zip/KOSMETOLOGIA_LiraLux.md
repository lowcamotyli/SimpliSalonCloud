﻿# KOSMETOLOGIA: Lira
Lux

Zweryfikuj zawartość karty zabiegowej dla zabiegu KOSMETOLOGIA: Lira
Lux
Czy aktualnie się Pan/i na coś leczy?
Tak    Nie
Jeśli tak, proszę zaznaczyć choroby:
Nie dotyczy
Choroby nowotworowe
Choroby serca
Choroby układu krążenia (nadciśnienie, miażdżyca)
Choroby naczyń krwionośnych (żylaki, zakrzepy)
Choroby płuc (astma, POChP)
Choroby układu pokarmowego (wrzody, refluks)
Choroby układu moczowego (nerki, pęcherz)
Zaburzenia metaboliczne (cukrzyca, insulinooporność)
Choroby tarczycy (niedoczynność, nadczynność, Hashimoto)
Zaburzenia hormonalne (HTZ, PCOS)
Choroby układu nerwowego (padaczka, migreny, SM)
Choroby krwi/krzepliwości
Choroby oczu (jaskra, zaćma)
Choroby skóry (AZS, łuszczyca, bielactwo, trądzik różowaty)
Czy pozostaje Pan/i pod opieką lekarza specjalisty?
Tak    Nie
Czy miał/a Pan/i wykonywane zabiegi chirurgiczne (operacje) w ostatnich 6 miesiącach?
Tak    Nie
Jeśli tak, to proszę wskazać miejsce poddane zabiegowi
Czy przyjmuje Pan/i leki na stałe?
Tak    Nie
Jeśli tak, proszę zaznaczyć przyjmowane grupy leków:
Nie dotyczy
Leki przeciwzakrzepowe (np. aspiryna, heparyna)
Leki na nadciśnienie/serce
Leki hormonalne (antykoncepcja, HTZ)
Leki na tarczycę (Euthyrox, Letrox)
Leki przeciwdepresyjne/psychotropowe
Leki przeciwbólowe/przeciwzapalne (przewlekle)
Antybiotyki (długotrwała kuracja)
Retinoidy (np. Izotek)
Inne
Czy obserwuje Pan/i problemy z układem pokarmowym, jelitami?
Nie, nie mam problemów
Tak, wzdęcia
Tak, zaparcia
Tak, biegunki
Tak, refluks/zgaga
Tak, bóle brzucha/skurcze
Tak, nietolerancje pokarmowe (np. laktoza, gluten)
Tak, zespół jelita drażliwego (IBS)
Czy objawy dotyczące układu pokarmowego są przewlekłe?
Nie dotyczy
Tak
Nie
Czy objawy związane z układem pokarmowym były diagnozowane przez lekarza?
Nie dotyczy
Tak
Nie
Jakie suplementy stosuje Pan/i na stałe?
Nie stosuję suplementów
Wit. AWit. BWit. CWit. DWit. EŻelazo
Magnez
Potas
Cynk
Kolagen
Kwas Omega-3/Omega-6Biotyna/suplementy na włosy, skórę, paznokcie
Probiotyki
Kwas hialuronowy
Czy korzystał/a Pan/i z inwazyjnych zabiegów kosmetologicznych?
Tak    Nie
Jeśli tak, proszę wybrać stosowane zabiegi:
Nie dotyczy
Peelingi chemiczne
Mikrodermabrazja/Dermabrazja
Mikronakłuwanie
Karboksyterapia
Sonoforeza/Jonoforeza
Radiofrekwencja LaseroterapiaHIFUEndermologia
Kriolipoliza
Elektrostymulacja mięśni
Kawitacja ultradźwiękowa
Laseroterapia
Inne
Czy korzystał/a Pan/i z zabiegów medycyny estetycznej?
Tak    Nie
Jeśli tak, to proszę wpisać datę ostatniego zabiegu
Jeśli tak, to proszę wybrać stosowane zabiegi:
Nie dotyczy
Botoks
Wypełniacze
Mezoterapia igłowa
Osocze/Fibryna
Stymulatory tkankowe
Nici liftingujące Biostymulatory kolagenu
Lipoliza iniekcyjna
Inne
Czy w okolicy zabiegowej używał/a Pan/i ostatnio jakiś kosmetyków/preparatów?
Nie używał/a ostatnio żadnych kosmetyków/preparatów w tej okolicy
Preparaty złuszczające (kwasy AHA, BHA, PHA)
Retinol / retinoidy
Kosmetyki wybielające / rozjaśniające przebarwienia
Antybiotyki miejscowe (np. na trądzik)
Maści steroidowe
Leki dermatologiczne (np. przeciwgrzybicze, przeciwwirusowe)
Kosmetyki silnie nawilżające/odżywcze (np. z mocznikiem >10%)
Czy w miejscu planowanego zabiegu występują u Pana/i jakiekolwiek anormalne/zmiany skórne lub schorzenia skóry?
Brak zmian skórnych w miejscu zabiegu
Zmiany barwnikowe (pieprzyki, znamiona, plamy)
Przebarwienia/odbarwienia
Trądzik (krosty, grudki, cysty)
Opryszczka aktywna/nawracająca
Uszkodzenia skóry (rany, zadrapania, blizny świeże)
Łuszczyca, AZSBrodawki/kurzajki
Infekcje bakteryjne/grzybicze
Czy przyjmuje Pan/i lub przyjmował/a Pan/i w ciagu ostatnich 6 miesięcy Izotek lub inne leki/maści na trądzik?
Nie, nie stosowałem/am w ostatnich 6 miesiącach żadnych leków ani maści na trądzik
Tak, przyjmuję/przyjmowałem/am izotretynoinę doustnie
Czy ma Pan/i na coś alergię?
Tak    Nie
Jeśli tak, proszę wybrać na co jest Pan/i uczulony/a:
Nie dotyczy
Lidokaina
Nikiel/metale
Leki (np. antybiotyki, aspiryna, NLPZ)
Kosmetyki/maści
Środki dezynfekcyjne (jodyna, spirytus)
Pyłki, kurz, alergeny środowiskowe
Lateks
Inne
Czy w przeszłości po jakimkolwiek zabiegu kosmetologicznym, estetycznym lub po nałożeniu jakiegokolwiek kosmetyku wystąpiły reakcje niepożądane?
Nie dotyczy
Zaczerwienienie utrzymujące się dłużej niż 24h
Obrzęk
Świąd
Wysypka/grudki
Pieczenie
Przebarwienia
Blizny/przerosty
Infekcje (np. opryszczka, ropienie)
Reakcja alergiczna potwierdzona
Jak ocenia Pan/i swój stan skóry?
Bardzo dobry
Dobry
Do poprawy
Jakie są Pana/i największe aktualne wyzwanie skórne?
Wiotka skóra
Przebarwienia
Blizny potrądzikowe
Zmarszczki
Suchość
Naczynka
Trądzik
Opadający owal
Przetłuszczanie
Rozszerzone pory
Zaskórniki/prosaki
Włókniaki
Blizny
Rozstępy
Cellulit
Czy stosuje Pan/i poranną rutynę pielęgnacyjną?
Tak
Nie
Staram się
Proszę wskazać produkty, których Pan/i używa:
Oczyszczanie 1-etapowe (żel/pianka/płyn micelarny)
Oczyszczanie 2-etapowe (olejek + żel/pianka)
Tonik/hydrolat/esencja
Serum nawilżające (np. kwas hialuronowy)
Serum z kwasami (np. AHA, BHA, PHA)
Serum z retinolem/retinoidami
Serum specjalistyczne (np. na przebarwienia, naczynka, trądzik)
Serum antyoksydacyjne (np. witamina C, resweratrol, ferulowy)
Serum matujące/regulujące sebum (np. niacynamid, cynk)
Krem na noc (nawilżający/odżywczy)
Krem pod oczy
Maska nocna / krem-maska
Olejki
Inne
Proszę wskazać produkty, których Pan/i używa:
Brak pielęgnacji porannej
Oczyszczanie twarzy (żel/pianka/micelarna)
Tonik/hydrolat/esencja
Serum nawilżające (np. kwas hialuronowy)
Serum antyoksydacyjne (np. witamina C, resweratrol, ferulowy)
Serum matujące/regulujące sebum (np. niacynamid, cynk)
Serum specjalistyczne (np. przeciwtrądzikowe, przeciw przebarwieniom)
Krem na dzień (nawilżający, odżywczy, matujący)
Krem pod oczy
Ochrona przeciwsłoneczna SPFMakijaż (podkład, puder, BB/CC)
Inne
Czy stosuje Pan/i wieczorną rutynę pielęgnacyjną?
Tak
Nie
Staram się
Jak często stosuje Pan/i ochronę przeciwsłoneczną?
Codziennie, reaplikuję
Raz dziennie
Tylko latem
Sporadycznie
Nie
Proszę wskazać stosowaną formę ochrony przeciwsłonecznej:
Krem SPF 15–30Krem SPF 50+Makijaż z filtrem (BB/CC, podkład)
Filtr mineralny
Filtr chemiczny
Inne
Czy pali Pan/i papierosy?
Tak, regularnie
Tak, okazjonalnie (np. kilka w tygodniu)
Nie, nigdy nie paliłem/am
Nie, ale paliłem/am w przeszłości
O której godzinie zwykle kładzie się Pan/i spać?
<22:0022-2323-24>24  
Ile godzin zwykle Pan/i śpi?
<7h7-8h8-9h>9h
Ile litrów wody pije Pan/i w ciągu dnia?
<1l1-1,5l1,5-2l2-2,5l>2,5l
Nie piję regularnie / trudno określić
W jakim środowisku spędza Pan/i najwięcej czasu?
Klimatyzowane
Nieklimatyzowane
Świeże powietrze
Czy planuje Pan/i urlop/wyjazd w najbliższym czasie?
Tak    Nie
Jeśli tak, proszę napisać dokąd
Czy jest Pani w ciąży?
Tak
Nie
Nie wiem
Czy karmi Pani piersią?
Tak
Nie
Nie dotyczy
Czy wystąpiły zmiany po ciąży?
Nie dotyczy
Cellulit
Przebarwienia
Wiotkość skóry brzucha / biustu
Blizna po cesarskim cięciu
Rozstępy
Inne
Czy korzysta Pan/i z solarium?
Nigdy
Sporadycznie (kilka razy w roku)
Regularnie (np. raz w tygodniu)
Intensywnie (kilka razy w tygodniu)
Kiedy ostatni raz korzystał Pan/i z solarium?
Nie dotyczyW ciągu ostatniego tygodniaW ciągu ostatniego miesiąca
Ponad miesiąc temu
Ponad rok temu
Czy uprawia Pan/i regularnie aktywność fizyczną?
Tak    Nie
Jeśli tak, to proszę wybrać częstotliwość:
Tak, sporadycznie (1 raz w tygodniu lub rzadziej)
Tak, 2–3 razy w tygodniu
Tak, 4–5 razy w tygodniu
Tak, codziennie
Rodzaj aktywności (można zaznaczyć kilka):
Spacery/marsze
Bieganie
Siłownia/fitness
Joga/pilates/stretching
Pływanie/sporty wodne
Sporty drużynowe
Inne
Określ swój styl odżywiania:
Nie zwracam szczególnej uwagi na dietę
Dieta bogata w owoce i warzywa
Dieta uboga w owoce i warzywa
Dostarczam mięso w diecie
Dieta bogata w gluten (makarony, pieczywo, ciasta)
Ograniczam gluten
Ograniczam nabiał
Unikam słodyczy i fast foodów
Spożywam dużą ilość słodyczy i fast foodów
Czy jest coś, o czym chciałby nam Pan/i powiedzieć?
Tak    Nie
Jeśli tak, to napisz
Wyrażam zgodę na przetwarzanie moich danych dotyczących zdrowia na potrzeby przeprowadzenia zabiegu.

## Klauzula informacyjna RODO

KLAUZULA INFORMACYJNA DOTYCZĄCA PRZETWARZANIA DANYCH OSOBOWYCHAdministratorem Twoich danych osobowych jest BRAVE EDUCATION SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ z siedzibą w POZNAŃ, przy ul. GŁOGOWSKA 216 (dalej jako „Administrator” lub „my”) Nasze dane kontaktowe:
Jeśli masz jakiekolwiek pytania odnośnie przetwarzania przez nas Twoich danych lub chcesz zrealizować swoje uprawnienia, skontaktuj się z nami na adres firmy lub adres e-mail: redsxiii@gmail.comW jakich celach i na jakich podstawach prawnych będziemy przetwarzać Twoje dane?
CEL: Wykonanie umowy (usługi) lub podjęcie działań przed jej zawarciem i działania związane z wykonaniem umowy – tj. np. wykonanie określonego zabiegu kosmetycznego, realizacja zamówienia produktu, doradztwo w zakresie zasad pielęgnacji, w tym ułożenie Beauty
Planów W tym celu możemy przesyłać na podany przez Ciebie adres e-mail lub numer telefonu informacje związane z umową np. zalecenia pozabiegowe, informacje związane z rejestracją konta w aplikacji, szczegóły dotyczące np. Beauty
Planów
PODSTAWA PRAWNA- w zakresie w jakim przetwarzanie danych jest niezbędne dla realizacji umowy – podstawą prawną będzie wykonanie umowy (podjęcie czynności niezbędnych przed nawiązaniem umowy) (art. 6 ust. 1 lit. b RODO); - w zakresie w jakim z wykonaniem umowy wiązać się będzie realizacja określonych obowiązków wynikających z przepisów prawa (np. podatkowych, księgowych etc.) podstawą prawną będzie stosowny przepis prawa (art. 6 ust. 1 lit. c RODO);- w zakresie w jakim przetwarzanie będzie wykraczać poza to co niezbędne dla zawarcia i wykonania umowy – będziemy przetwarzać dane związane z umową w oparciu o prawnie uzasadniony interes – np. w związku z wysyłaniem zaleceń pozabiegowych, rejestracją w systemie, wysyłaniem informacji dotyczących Beauty
Planu, etc. (art. 6 ust. 1 lit. f RODO); - dane możemy również przetwarzać w zakresie niezbędnym dla ustalenia, dochodzenia lub obroną przed roszczeniami, w tym zgłoszeniem szkód do ubezpieczyciela w oparciu o nasz prawnie uzasadniony interes (art. 6 ust. 1 lit. f RODO).
SPRZECIW: W przypadku przetwarzania przez nas danych w oparciu o prawnie uzasadniony interes masz prawo zgłoszenia sprzeciwu z przyczyn związanych ze swoją szczególną sytuacją. Sprzeciw możesz zgłosić pisząc do nas na adres e-mail redsxiii@gmail.com- dane o stanie zdrowia (np. dane o przyjmowanych lekach, przebytych chorobach, alergiach, ciąży etc. podane przez Ciebie) - w zakresie w jakim jest to niezbędne dla bezpiecznego wykonania zabiegów - u nas są przetwarzane na podstawie wyraźnej zgody na ich przetwarzanie (art. 9 ust. 2 lit. a RODO). Zgoda jest dobrowolna, lecz niezbędna do korzystania z zabiegów kosmetycznych (wykonania umowy).
Do czasu rozpoczęcia zabiegu możesz wycofać zgodę ustnie w Salonie, wówczas pracownik Salonu poczyni odpowiednią notatkę w aplikacji. Wycofanie zgody nie wpływa na zgodność z prawem przetwarzania, którego dokonano na podstawie zgody przed jej wycofaniem.Po rozpoczęciu wykonywania zabiegu dane o stanie zdrowia będą przechowywane dla celów ustalenia, dochodzenia lub obrony przed roszczeniami na podstawie art. 9 ust. 2 lit. f. RODO.
CEL: Odpowiedzi na zapytania
PODSTAWA PRAWNAPodstawą prawną jest nasz prawnie uzasadniony interes polegający na konieczności ustosunkowania się do Twojego zapytania (art. 6 ust. 1 lit. f RODO).
SPRZECIW: W przypadku przetwarzania przez nas danych w oparciu o prawnie uzasadniony interes masz prawo zgłoszenia sprzeciwu z przyczyn związanych ze swoją szczególną sytuacją. Sprzeciw możesz zgłosić pisząc do nas na adres e-mail redsxiii@gmail.comW przypadku, gdy odpowiedzi na zapytania dotyczą umówienia usługi lub zakupu produktu podstawą prawną może być czynność bezpośrednio poprzedzająca zawarcie umowy (art. 6 ust. 1 lit. b RODO).
CEL: Wnioski dotyczące realizacji praw wynikających z RODO lub innych właściwych przepisów
PODSTAWA PRAWNAPodstawą prawną jest nasz obowiązek prawny (art. 6 ust. 1 lit. c RODO) związany z koniecznością realizacji praw osób, których dane dotyczą oraz wykazania prawidłowości wykonania naszych obowiązków.
CEL: Reklamacje
PODSTAWA PRAWNAPodstawą prawną jest nasz lub Twój prawnie uzasadniony interes polegający na komunikacji w związku z daną reklamacją, a następnie w celu obrony przed roszczeniami (art. 6 ust. 1 lit. f RODO).
SPRZECIW: W przypadku przetwarzania przez nas danych w oparciu o prawnie uzasadniony interes masz prawo zgłoszenia sprzeciwu z przyczyn związanych ze swoją szczególną sytuacją. Sprzeciw możesz zgłosić pisząc do nas na adres e-mail redsxiii@gmail.com
Czy podanie Twoich danych jest obowiązkowe?Podanie danych jest dobrowolne. Jednakże niepodanie danych, które są niezbędne dla realizacji określonych powyżej celów może odpowiednio uniemożliwić realizację tych celów, np. niepodanie wymaganych danych będzie skutkować niemożnością wykonania zabiegu, zamówienia produktu itp.
Jak długo przechowujemy Twoje dane?Twoje dane przechowujemy przez następujące okresy w zależności od podstaw prawnych (celów przetwarzania):Wykonanie umowy oraz czynności poprzedzające lub związane z wykonaniem umowy: Twoje dane będą przechowane tak długo jak to jest niezbędne dla realizacji celów dla których zostały zebrane, w tym wykonania umowy (np. przeprowadzenia zabiegu, dostarczenia produktu, odpowiedzi na zapytanie które można zakwalifikować jako czynność poprzedzającą zawarcie umowy) który to okres zostanie wydłużony o stosowny okres przedawnienia roszczeń.Nasze obowiązki prawne: W przypadkach, gdy przetwarzanie Twoich danych służy realizacji obowiązków wynikających z przepisów prawa, będziemy przechowywać Twoje dane przez okresy wskazane w takich przepisach obowiązującego prawa.Twoja zgoda: Twoje dane będą przetwarzane do czasu wycofania udzielonej przez Ciebie zgody na ich przetwarzanie. W przypadkach w których te same dane są przetwarzane również w innych celach, w oparciu o inne podstawy prawne, będziemy mogli je przetwarzać w oparciu o inną niż zgoda właściwą podstawę prawną nawet po wycofaniu przez Ciebie zgody.Prawnie uzasadniony interes: Twoje dane będą przetwarzane do czasu zgłoszenia przez Ciebie skutecznego sprzeciwu względem ich przetwarzania lub do czasu gdy wykażemy istnienie podstaw do ustalenia, dochodzenia lub obrony roszczeń. Oznacza to, że po zgłoszeniu przez Ciebie sprzeciwu dokonamy wyważenia Twoich i naszych interesów. Wówczas nie będziemy już przetwarzać Twoich danych osobowych, chyba że wykażemy istnienie ważnych prawnie uzasadnionych podstaw do przetwarzania, nadrzędnych wobec Twoich interesów, praw i wolności, lub istnienie podstaw do ustalenia, dochodzenia lub obrony roszczeń.
Gdzie są przetwarzane Twoje dane osobowe?Twoje dane osobowe są przetwarzane, w tym przechowywane na terenie Europejskiego Obszaru Gospodarczego.
Komu są przekazywane Twoje dane osobowe?Odbiorcami Twoich danych osobowych są podmioty z nami współpracujące lub dostarczające usługi na naszą rzecz, np. podmioty zajmujące się obsługą systemów IT, archiwizacją dokumentacji, obsługą prawną, rachunkowo - księgową czy też jakiekolwiek inne podmioty, z którymi zawarliśmy umowę powierzenia przetwarzania danych i które są zobowiązane do przetwarzania Twoich danych zgodnie z naszymi wskazówkami. Odbiorcami Twoich danych mogą być także organy nadzorujące przestrzeganie prawa, organ regulacyjne i inne organy administracji publicznej, sądy i organy ścigania (wyłącznie w zakresie wynikającym z obowiązujących przepisów prawa).
Jakie są Twoje prawa?Możesz zwrócić się do nas z określonym żądaniem za pośrednictwem adres e-mail redsxiii@gmail.com lub na nasz adres korespondencyjny. Prosimy wówczas o wskazanie z jakiego prawa i w jakim zakresie chcesz skorzystać. Po wpłynięciu Twojego żądania i ewentualnej weryfikacji Twojej tożsamości podejmiemy w związku z Twoim żądaniem odpowiednie działania.Zgodnie z prawem otrzymasz od nas stosowną odpowiedź tak szybko, jak to możliwe, ale (co do zasady) nie później niż w ciągu miesiąca. W sytuacji, w której Twoje żądanie jest skomplikowane lub prosisz nas jednocześnie o realizację wielu żądań, termin ten może został przedłużony maksymalnie o kolejne dwa miesiące. W takim przypadku zostaniesz poinformowany/poinformowana o takim przedłużeniu terminu.Przysługują Tobie następujące prawa:- prawo dostępu do treści swoich danych, otrzymania ich kopii, żądania ich sprostowania, usunięcia lub ograniczenia ich przetwarzania;- wniesienia sprzeciwu wobec przetwarzania danych osobowych z przyczyn związanych z Twoją szczególną sytuacją w zakresie, w jakim podstawą przetwarzania danych osobowych jest prawnie uzasadniony interes;- przenoszenia danych osobowych w zakresie, w jakim Twoje dane są przetwarzane w celu zawarcia i wykonywania umowy lub na podstawie zgody;- wycofania wyrażonej zgody w dowolnym momencie bez wpływu na legalność przetwarzania dokonanego przed takim wycofaniem. W przypadkach w których te same dane są przetwarzane również w innych celach, w oparciu o inne podstawy prawne, będziemy mogli je przetwarzać w oparciu o inną niż zgoda właściwą podstawę prawną. Wówczas poinformujemy Cię o tym;- Ochrona Twoich danych osobowych jest dla nas priorytetem.
Jeśli jednak uznasz, że przetwarzając Twoje dane osobowe naruszamy RODO, masz prawo wniesienia skargi do Prezesa Urzędu Ochrony Danych Osobowych adres: Stawki 2, 00-193 Warszawa.
ZGODA NA ZABIEG I ZWIĄZANE Z NIM PRZETWARZANIE DANYCH O STANIE ZDROWIANiniejszym oświadczam, że wyrażam świadomą zgodę na wykonanie powyższego zabiegu. Oświadczam, że poinformowano mnie o:1. możliwych powikłaniach,2. powikłaniach nietypowych,3. ryzyku zabiegu i jego następstwach,4. przeciwskazaniach do wykonania zabiegu,5. szczegółowej technice wykonania zabiegu,6. sposobie wykonania zabiegu.Ponadto oświadczam, że miałem/miałam możliwość zadawania wszelkich pytań i uzyskania wyjaśnień jakich oczekiwałem/oczekiwałam. Rozumiem, że pozytywne efekty zabiegu nie są zagwarantowane. Wszystkie informacje przekazane przez kosmetologa są dla mnie w pełni jasne i zrozumiałe. Jednocześnie oświadczam, że udzieliłem/udzieliłam aktualnych i kompletnych informacji co do mojego stanu zdrowia.Mam świadomość, że dla bezpiecznego wykonania zabiegów muszę podać dane o stanie zdrowia (np. dane o alergiach, stosowanych lekach, chorobach, ciąży) wskazane w karcie zabiegowej. Niniejszym składając poniżej podpis wyrażam wyraźną zgodę na ich przetwarzanie w celu wykonania zabiegów.Wycofanie zgody jest możliwe do czasu rozpoczęcia zabiegu ustnie w Salonie. Wówczas pracownik Salonu poczyni odpowiednią notatkę w aplikacji. Wycofanie zgody nie wpływa na zgodność z prawem przetwarzania, którego dokonano na podstawie zgody przed jej wycofaniem. Po rozpoczęciu wykonywania zabiegu dane o stanie zdrowia będą przechowywane dla celów ustalenia, dochodzenia lub obrony przed roszczeniami na podstawie art. 9 ust. 2 lit. f. RODO.

